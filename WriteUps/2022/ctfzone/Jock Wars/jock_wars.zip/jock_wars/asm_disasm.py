from keystone import Ks
from keystone import KS_ARCH_X86, KS_MODE_16
from keystone import KS_ARCH_ARM64, KS_MODE_LITTLE_ENDIAN

from capstone import Cs
from capstone import CS_ARCH_X86, CS_MODE_16
from capstone import CS_ARCH_ARM64, CS_MODE_ARM

class Computer:
    def compile(self, CODE):
        try:
            return self.ks.asm(CODE)[0]
        except:
            return b''

    def disasm(self, CODE):
        return list(map(lambda i: "0x%x:\t%s\t%s" %(i.address, i.mnemonic, i.op_str), self.md.disasm(CODE, 0x0)))

class X86_16(Computer):
    def __init__(self):
        self.ks = Ks(KS_ARCH_X86, KS_MODE_16)
        self.md = Cs(CS_ARCH_X86, CS_MODE_16)

class AARCH64(Computer):
    def __init__(self):
        self.ks = Ks(KS_ARCH_ARM64, KS_MODE_LITTLE_ENDIAN)
        self.md = Cs(CS_ARCH_ARM64, CS_MODE_ARM)
