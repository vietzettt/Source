# Overview

Jock Wars is a shellcode fighting game with base capturing mechanics.

The game is played over a bunch of 5-minute rounds. During each round, the players are divided into groups of 8, with each group fighting over control of a randomly-generated pool of nodes based on X86-16 (blue) and AArch64 (red) architecture. An empty node is captured by solving a task. An occupied node has to be additionally taken from the other player in the Slum, a separate processor with a custom architecture.

The players' objective is to capture as much nodes as possible losing as few of them as possible.

To achieve their objective, each player has to write a pair of shellcodes: one for capturing nodes and the other for fighting in the arena. If one of the shellcodes is not doing its job well, a player can edit it or write a new one for subsequent rounds.

The game ends with an execution of the 5,000th instruction. The players are scored based on the number of total nodes they had by the end of each round.

# Rules

## Objective

The game is played over a number of rounds, each round being 5 minutes long.

Each round players are divided into groups of 8, dealing with a randomly-generated pool of nodes. Players capture these nodes and defend them from the other players in the fighting arena.

The objective is to capture as much nodes as possible losing as few of them as possible.

At the end of each round, the players are scored based on the number of nodes at their control.

The game ends with an execution of the 5,000th instruction. After that, scores from all rounds are summed.

## Matchmaking

Players are assigned to a group by their positions on the scoreboard at the start of the new round: the better you are, the tougher your group will be.

For instance, Group 1 consists of players from top 1 to top 7, Group 2 consists of players from top 8 to top 15, and so on.

## Scoring system

Players are scored at the end of each round per the following script:

```python
total = 0
for single_round in all_rounds:
    total += single_round.captured_nodes
```

## Nodes

Nodes are processors based either on X86-16 or AArch64 architecture. The architecture is assigned randomly for each node.

Player captures each node by solving a task, randomly assigned to it.

If a node is empty, that's it, the player owns the node.

If a node is occupied by another player, the players fight over it in the Slum, a 2D fighting game arena running on our own custom architecture. Whoever wins the fight, owns the node.

## Shellcodes

Jock Wars are fought with a pair of shellcodes written by the players.

There are two types of shellcodes: Observer and Warrior.

 - **Observer** runs in nodes and solves the tasks they store. After it submits the right solution, the player gets the node or goes on to fight for it. If the player captures the node (one way or another), Observer goes on to run on an adjacent node. Since the nodes' architectures may vary even in one pool, the Observer shellcode has to run correctly on both X86-16 and AArch64. **You can compile this type of shellcode for AArch64 using /test page**.

 - **Warrior** fights for the player over control of the nodes, be it to capture new nodes or defend the owned ones. It runs on the custom architecture of the Slum and is represented by a character in a 2D fighting game arena.

# Technical information

## Nodes

### Memory regions for X86-16 and AArch64
```C
0x0    - 0x1000    rwx   .text
0x1000 - 0x2000    rw    stack
```

### Registers mapping for AArch64
- Syscall number register - x8
- arg1 - x0
- arg2 - x1
- arg3 - x2
- ..................
- arg8 - x7
- Stack pointer - SP
- Instruction pointer - IP

### Registers mapping for X86-16
- Syscall number register - AX
- arg1 - DI
- arg2 - SI
- arg3 - DX
- arg4 - CX
- arg5 - BX
- Stack pointer - SP
- Instruction pointer - IP

### Registers initial state

Initially all registers are equal to 0 except SP: it equals 0x1500.

### Tasks

#### AddTask
```C
Task_id = 1
  
output for sys_get_task:

arg1 (14-bit unsigned): first summand

arg2 (14-bit unsigned): second summand
```

#### BruteTask
```C
Task id = 2

Possible answers: from 0 to 15 included

output for sys_get_task:

none
```

## Observer shellcode

### Syscalls

The main tool Observer shellcode has in this game is the ability of making syscalls. Basically, all the dirty work is done with system calls.

#### How to make a syscall
- AArch64: svc 0x1337
- X16: int 0x80

#### sys_get_count_nearby
```C
Syscall number is 0x1337

Get count of nearby nodes


input:

none

output:

arg1: quantity of nearby nodes
```

#### sys_get_nearby_info
```C
Syscall number is 0x1338

Get adjacent node info


input:

arg1: node number in nearby_nodes list (from 0 to count_nearby-1)

output:

arg1: architecture id (1 for AArch64, 2 for X86-16)

arg2: task id (explained in task specifications)

arg3: team id
```

#### sys_get_task
```C
Syscall number is 0x1339

Get task from nearby node



input:

arg1: node number in nearby_nodes list (from 0 to count_nearby-1)

output:

see task specification
```

#### sys_approve_task
```C
Syscall number is 0x133a

Approve task for nearby node


input:

arg1: node number in nearby_nodes list (from 0 to count_nearby-1)

arg2: answer

output:

arg1: 0 if correct, 1 if incorrect, 2 if you lose the fight
```

### Shellcode optimization

In our system you don't need to optimize shellcode size. Instead you should optimize the amount of instructions your shellcode will execute. 

This is how it works: we execute the very first instruction on the 1st node then we execute the very first instruction on the 2nd node and etc. Then when we execute 1st instruction on all nodes we move to the 2nd instruction.

## The Slum

### CPU instruction and opcodes
Instruction in this processor looks like this
```
       OPCODE         [TYPE]           [ARGS...]
          |              |                 |
    opcode number  type of operation   operands
```
```
opcode numbers:
    0: mov
    1: add
    2: sub
    3: mul
    4: div
    5: and
    6: xor
    7: or
    8: cpuid
    9: inc
    10: dec
    11: call
    12: ret
    13: push
    14: pop
    15: cmp
    16: jmp
    17: jcc
    18: rol
    19: ror
    20: shr
    21: shl
    22: hit
    23: left
    24: right
    25: jump
    26: parry
    27: noop
    28: status
    29: mod
```
CPU has 32 registers, including 29-bp, 30-sp, 31-pc and non-accessible 32-FLAGS, which is modified and read by cmp and jcc accordingly

#### mov

Moves value/register into register/memory

Possible types:

    0: move qword value from reg to reg (mov reg, reg)
    1: move dword value from reg to reg
    2: move word value from reg to reg
    3: move byte value from reg to reg
    4: move qword value to reg (mov reg, val)
    5: move dword value to reg
    6: move word value to reg
    7: move byte value to reg
    8: move qword value from memory located in register to register (mov reg, [reg])
    9: move dword value from memory located in register to register
    10: move word value from memory located in register to register
    11: move byte value from memory located in register to register
    12: write qword value from register to memory located in register (mov [reg], reg)
    13: write dword value from register to memory located in register
    14: write word value from register to memory located in register
    15: write byte value from register to memory located in register
    16: write qword value to memory located in register (mov [reg], val)
    17: write dword value to memory located in register
    18: write word value to memory located in register
    19: write byte value to memory located in register

#### add
Adds value/register to register
Possible types will be shown later

#### sub
Unsigned subtraction of value/register from register
Possible types will be shown later

#### mul
Multiply register value by register/value
Possible types will be shown later

#### div
Unsigned integer division of register by register/value
Possible types will be shown later

#### mod
Modulus of register divided by register/value
Possible types will be shown later

#### and
Bitwise and of register with register/value
Possible types will be shown later

#### xor
Bitwise xor of register with register/value
Possible types will be shown later

#### or
Bitwise or if register with register/value
Possible types will be shown later

#### Types of add/sub/mul/div/mod/and/xor/or
    0: op qword value from reg to reg (op reg, reg)
    1: op dword value from reg to reg
    2: op word value from reg to reg
    3: op byte value from reg to reg
    4: op qword value to reg (op reg, val)
    5: op qword value from memory located in register to register (op reg, [reg])
    6: op dword value from memory located in register to register
    7: op word value from memory located in register to register
    8: op byte value from memory located in register to register
    9: modify qword value from register to memory located in register (op [reg], reg)
    10: modify dword value from register to memory located in register
    11: modify word value from register to memory located in register
    12: modify byte value from register to memory located in register

#### cpuid
Moves to r0 value 7521962925287694670 and moves to r1 value 2408985254898789993

#### inc
Increment register value by 1

#### dec
Decrement register value by 1

#### call
Push next instruction address to stack and jump to address, defined by register/value
Possible types:

    0: call register
    1: call value

#### ret
pop address from stack and jump to it

#### push
Push register/qword value to stack
Possible types are similar to call

#### pop
Pop qword value from stack

#### cmp
Compare register with register/value
Possible types are similar to call
Comparision raises this flags
    SF if first operand is less, than second operand
    ZF if operands are equal


#### jmp
Jump to address defined by register/value
Possible types are similar to call

#### jcc
Conditional jump. In assembler does not exist, instead, it has this mnemonics

    0: jeq/jz; ZF == 1
    1: jne; ZF == 0
    2: jge/ja; SF == 0 || ZF == 1
    3: jle/jb; SF == 1 || ZF == 1
    4: jg; SF == 0 && ZF == 0
    5: jl; SF == 1 && ZF == 0
    
Possible types are similar to call
This instruction differs from other, containing one extra byte after opcode, which defines type of condition
After this byte, syntax is equal to jmp

#### rol
Rotate right register by register/value
Possible types are similar to call

#### ror
Rotate left register by register/value
Possible types are similar to call

#### shr
Shift right register by register/value
Possible types are similar to call

#### shl
Shift left register by register/value
Possible types are similar to call

#### hit
Send hit event to the game

#### left
Send left event to the game

#### right
Send right event to the game

#### jump
Send jump event to the game

#### parry
Send parry event to the game

#### noop
Send noop event to the game

#### status
Retrieve the status of the game
Status of the game is filled to r0 and r1 registers from least significant byte to most significant byte. Data is filled according to this
    0: Your player number
    1: Player 1 HP
    2: Player 1 X position
    3: Player 1 Y position
    4: Player 1 stun effect length
    5: Player 2 HP
    6: Player 2 X position
    7: Player 2 Y position
    8: Player 2 stun effect length

### CPU regions

Here, everything is very simple. Everything is rwx, but your memory is limited by 16-bit integer. 0x8000 is valid address, while 0x10000 is not.

Your code is placed at 0 with ALL registers set to 0. It means that you should choose region for sp yourself.

### Assembler reference

#### Instructions
Basically, all instructions and its syntax were described above. You write

`INSN [OP1], [OP2]`

For values you can use decimal number, or hex number, which should either end with `h` or start with `0x`.

E.g.:

```
mov r0, 0x1337
shr r0, 10
inc r0
dec r0
push bp
mov bp, sp
mov sp, bp
pop bp
hit
jump
parry
...
```

#### Label declaration

You can declare a label, which you can use later in code (for example, if you need functions).

For example:
```
.label
    jmp .label
```
Or
```
jmp .main
.func
    ret
.main
    hit
    jmp .main
```

The only limitation is that you can't define address for label yourself. It means that if you want to store something, you need to specify the address, like

```
mov r0, 0x1000
mov [r0], 0x1000
```
#### Specifying operand size
This applies to instructions, that can work with different operand sizes, mainly mov and arithmetic operations.

You can specify prefix in beginning of any operand on line with instruction after operation.

Possible prefixes: BYTE, WORD, DWORD, QWORD. 8, 16, 32 and 64 bits accordingly.

For example:

```
mov QWORD r0, 123
mov r0, QWORD 123
```

Note that you can only use one prefix, so `mov QWORD r0, DWORD 1234` will not work.

Assembler is adaptive, so first it will try to fit 123 in BYTE, but if it explicitly said, that it should fit 123 into QWORD.

In case you entered value that not fits in specifier, assembler will report Integer overflow.

### Mechanics
- Warriors spawn at 5 and 15 X position and 0 Y position with HP = 100.
- Game field is limited by 20 X pos and 1 Y pos.
- If a Warrior fails to do an operation (e.g. segmentation fault, invalid opcode), it is automatically KO'd.
- If a Warrior does 5 status operations in the row without doing much else, it is automatically KO'd.
- If a Warrior does 10,000 operations without submitting an action, it is automatically KO'd.
- If a Warrior's hp <= 0, it is KO'd.
- Hit will work if a Warrior's X and Y coord are less than 2 away from the other Warrior.
- Normal hit will consume 5 HP from a Warrior.
- If a Warrior hits while his Y coord is higher (насколько?) than Y coord of his opponent, he deals critical damage (normal hit x2).
- Warrior can jump only 2 times sequentially.
- If the Warrior parries and the other Warrior hits it, it gets no damage while the other Warrior is stunned for:
    - 2 moves if it tried a normal hit,
    - 3 moves if it tried a critical hit.
- If the Warrior parries 2 times in a row and the other Warrior hits it, the Warrior takes less damage (basically 2).
- If the Warrior parries more than 3 times in a row and the other Warrior hits it, the Warrior takes full damage (basically 5)

The Slum performs hits/parries first, moves after that.

A fight in the Slum lasts up 100 moves. If nobody is dead, defender wins.

If 2 players die at the same time, defender wins.
